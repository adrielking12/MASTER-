// Game logic
const board = document.getElementById('game-board');
const cells = Array.from(board.getElementsByClassName('cell'));
const resetButton = document.getElementById('reset-btn');
let currentPlayer = 'X';
let gameBoard = ['', '', '', '', '', '', '', '', ''];
let isGameActive = true;

const winPatterns = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
    [0, 4, 8], [2, 4, 6]             // Diagonals
];

const checkWinner = () => {
    for (let pattern of winPatterns) {
        const [a, b, c] = pattern;
        if (gameBoard[a] && gameBoard[a] === gameBoard[b] && gameBoard[a] === gameBoard[c]) {
            highlightWinner(pattern);
            return gameBoard[a];
        }
    }
    return null;
};

const highlightWinner = (pattern) => {
    pattern.forEach(index => {
        cells[index].classList.add('winner');
    });
    drawLine(pattern);
};

const drawLine = (pattern) => {
    // This is a placeholder. Implement actual line drawing logic if needed.
};

const handleCellClick = (e) => {
    const index = e.target.dataset.index;
    if (gameBoard[index] || !isGameActive) return;
    
    gameBoard[index] = currentPlayer;
    e.target.innerText = currentPlayer;
    const winner = checkWinner();
    if (winner) {
        alert(`${winner} wins!`);
        isGameActive = false;
    } else if (!gameBoard.includes('')) {
        alert("It's a draw!");
        isGameActive = false;
    } else {
        currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    }
};

const resetGame = () => {
    gameBoard = ['', '', '', '', '', '', '', '', ''];
    isGameActive = true;
    currentPlayer = 'X';
    cells.forEach(cell => {
        cell.innerText = '';
        cell.classList.remove('winner');
    });
};

cells.forEach(cell => cell.addEventListener('click', handleCellClick));
resetButton.addEventListener('click', resetGame);
